﻿/*********************************************
 Select_ML.cs
 	Symptom Cheker (alpha)

  Writing by Sergey Gasanov, may-aug,2015 
  version: 0.4
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Select_ML: MonoBehaviour 
{
	public GameObject S_GENERAL;			// General symptoms (group)
	public GameObject S_SHOULDERS; 			// Shoulders symptoms (group)
	public GameObject S_HEAD; 				// HEAD symptoms (group)
	public GameObject S_NECK; 				// NECK symptoms (group)
	public GameObject S_CHEST; 				// CHEST symptoms (group)
	public GameObject S_ABDOMEN; 			// ABDOMEN symptoms (group)
	public GameObject S_PELVIS; 			// PELVIS symptoms (group)
	public GameObject S_LEGS; 				// LEGS symptoms (group)
	public GameObject S_HANDS; 				// HANDS symptoms (group)

	public SkinnedMeshRenderer daz_mesh;	// DAZ Model
	public GameObject P_Select;				// SELECT PANEL - text "You Selected"	
	public Text T_BodyName;     			// SELECT PANEL - text "Name Body Parts"  

	// MATERIALS CHANGE
	public Material Glow;			
	public Material Red;	
	
	static bool sel; 				// Flag Select (local)
	static string PartName;		    // Name body part

	private string ntemp = ""; 
	private Material[] CasheMat; 
	private Material[] TempMat; 
	
	void Start ()
	{
		CasheMat = daz_mesh.materials;
		sel = false;
	}

	void Update () 
	{
	
		if (!sel)
			P_Select.SetActive(false);		// SELECT PANEL - text "You Selected"
		else
			P_Select.SetActive(true);

		if (T_BodyName.text == "") 
		{
			S_GENERAL.SetActive (true);		//*** GENERAL SYMPTOMS ***
			S_SHOULDERS.SetActive (false);
			S_HEAD.SetActive (false);
			S_NECK.SetActive (false);
			S_CHEST.SetActive (false);
			S_ABDOMEN.SetActive (false);
			S_PELVIS.SetActive (false);
			S_LEGS.SetActive (false);		
			S_HANDS.SetActive (false);

			P_Select.SetActive (false);		// SELECT PANEL - text "You Selected"
		}

	}


	/*------------------------
		OnMouseEnter
	------------------------*/
	void OnMouseEnter ()
	{
		if (!sel) 
		{
			PartName = this.gameObject.name;
			T_BodyName.text = PartName;

			// ---- If no rotate (orbit)
			if (!Input.GetMouseButton (1)) {
				int ind = FindIndexMat (PartName);
				ChangeMat (ind);
			}
		}

		P_Select.SetActive(false);	
	}
	
	/*------------------------
		    OnMouseExit
	------------------------*/
	void OnMouseExit ()
	{
		if (!sel) 
		{
			RestoreMat ();
			T_BodyName.text = ntemp;
		}
	}
	
	/**********************************
		   OnMouseDowm (Select)
	***********************************/
	void OnMouseDown ()
	{
		if (!sel) 
		{
			sel = true;
			PartName = this.gameObject.name;
			T_BodyName.text = PartName;
			int ind = FindIndexMat (PartName);
			ChangeMat (ind);
			INQUIRER (PartName);
		} 
		else 
		{
			sel = false;
			daz_mesh.materials = CasheMat;
		}
	}
	
	/**********************************
		      INQUIRER (Menu)
	***********************************/
	void INQUIRER (string name)
	{
		//string InqName = "INQUIRER -->" + name;
		string InqName = name;
		T_BodyName.text = InqName;
		QUIZ_PANEL_ON (name);
		Debug.Log ("INQUIRER -->" + InqName);
		
	}
	

	/*------------------------
		QUIZ_PANEL_ON
	------------------------*/
	void QUIZ_PANEL_ON (string body_name)
	{
		switch (body_name)
		{
		
		//****** SHOULDERS *******
		case "LEFT SHOULDER":
		case "RIGHT SHOULDER":
		case "LEFT SHOULDER JOINT":
		case "RIGHT SHOULDER JOINT":
			S_GENERAL.SetActive(false);
			S_SHOULDERS.SetActive(true);	//***
			S_HEAD.SetActive(false);
			S_NECK.SetActive(false);
			S_CHEST.SetActive(false);
			S_ABDOMEN.SetActive(false);
			S_PELVIS.SetActive(false);
			S_LEGS.SetActive(false);
			S_HANDS.SetActive(false);
			break;

		//------- HEAD ---------
		case "HEAD":
			S_GENERAL.SetActive(false);
			S_SHOULDERS.SetActive(false);
			S_HEAD.SetActive(true);			//***
			S_NECK.SetActive(false);
			S_CHEST.SetActive(false);
			S_ABDOMEN.SetActive(false);
			S_PELVIS.SetActive(false);
			S_LEGS.SetActive(false);
			S_HANDS.SetActive(false);
			break;
			
		//------- NECK ---------
		case "NECK":
			S_GENERAL.SetActive(false);
			S_SHOULDERS.SetActive(false);
			S_HEAD.SetActive(false);
			S_NECK.SetActive(true);			//***
			S_CHEST.SetActive(false);
			S_ABDOMEN.SetActive(false);
			S_PELVIS.SetActive(false);
			S_LEGS.SetActive(false);
			S_HANDS.SetActive(false);
			break;
			
		//------- ABDOMEN ---------
		case "ABDOMEN":
			S_GENERAL.SetActive(false);
			S_SHOULDERS.SetActive(false);
			S_HEAD.SetActive(false);
			S_NECK.SetActive(false);
			S_CHEST.SetActive(false);
			S_ABDOMEN.SetActive(true);		//***
			S_PELVIS.SetActive(false);
			S_LEGS.SetActive(false);
			S_HANDS.SetActive(false);
			break;
			
		//------- CHEST ---------
		case "CHEST":
			S_GENERAL.SetActive(false);
			S_SHOULDERS.SetActive(false);
			S_HEAD.SetActive(false);
			S_NECK.SetActive(false);
			S_CHEST.SetActive(true);		//***
			S_ABDOMEN.SetActive(false);
			S_PELVIS.SetActive(false);
			S_LEGS.SetActive(false);
			S_HANDS.SetActive(false);
			break;
			
		//------- PELVIS ---------
		case "PELVIS":
			S_GENERAL.SetActive(false);
			S_SHOULDERS.SetActive(false);
			S_HEAD.SetActive(false);
			S_NECK.SetActive(false);
			S_CHEST.SetActive(false);
			S_ABDOMEN.SetActive(false);
			S_PELVIS.SetActive(true);		//***
			S_LEGS.SetActive(false);
			S_HANDS.SetActive(false);
			break;	
			
		//------- LEGS ---------
		case "LEFT SHIN":
		case "RIGHT SHIN":
		case "LEFT THIGH":
		case "RIGHT THIGH":
		case "LEFT FOOT":
		case "RIGHT FOOT":
		case "LEFT KNEE JOINT":
		case "RIGHT KNEE JOINT":
			S_GENERAL.SetActive(false);
			S_SHOULDERS.SetActive(false);
			S_HEAD.SetActive(false);
			S_NECK.SetActive(false);
			S_CHEST.SetActive(false);
			S_ABDOMEN.SetActive(false);
			S_PELVIS.SetActive(false);
			S_LEGS.SetActive(true);		//***
			S_HANDS.SetActive(false);
			break;

		//----- HANDS ------
		case "RIGHT FOREARM":
		case "LEFT FOREARM":
		case "RIGHT HAND":
		case "LEFT HAND":
		case "RIGHT WRIST":
		case "LEFT WRIST":
		case "LEFT ELBOW JOINT":
		case "RIGHT ELBOW JOINT":
			S_GENERAL.SetActive(false);
			S_SHOULDERS.SetActive(false);
			S_HEAD.SetActive(false);
			S_NECK.SetActive(false);
			S_CHEST.SetActive(false);
			S_ABDOMEN.SetActive(false);
			S_PELVIS.SetActive(false);
			S_LEGS.SetActive(false);
			S_HANDS.SetActive(true);	//***
			break;	
					
		default:
			break;
		}
		
	}
	
	/*------------------------
		    ChangeMat
	------------------------*/
	void ChangeMat (int i)
	{	
		// Material[] mats = new Material[] { Red, Glow, Glow, Red, Glow, Red, Glow, Red, Glow, Red, Glow, Red };
		TempMat = daz_mesh.materials;
		TempMat [i] = Glow;
		
		if (i == 16) // if select HEAD  
		{
			TempMat [20] = Glow;
			TempMat [21] = Glow;
		}
		
		daz_mesh.materials = TempMat;
	}
	
	/*------------------------
		    RestoreMat
	------------------------*/
	void RestoreMat ()
	{	
		daz_mesh.materials = CasheMat;
	}
	
	/*------------------------
           FindIndexMat
	------------------------*/
	int FindIndexMat (string name)
	{
		int index = 0;
		
		switch (name)
		{
			
		case "HEAD":
			index = 16; // and 7 - Head Back, 23 - Ears, 10 - Lips
			break;

		case "NECK":
			index = 28;
			break;
			
		case "ABDOMEN":
			index = 30;
			break;
			
		case "CHEST":
			index = 31;
			break;
			
		case "PELVIS":
			index = 29;
			break;
			
		case "RIGHT SHOULDER":
			index = 27;
			break;
			
		case "LEFT SHOULDER":
			index = 25;
			break;
			
		case "RIGHT SHOULDER JOINT":
			index = 26;
			break;
			
		case "LEFT SHOULDER JOINT":
			index = 24;
			break;
			
		case "RIGHT FOREARM":
			index = 37;
			break;
			
		case "LEFT FOREARM":
			index = 34;
			break;
			
		case "LEFT ELBOW JOINT":
			index = 33;
			break;
			
		case "RIGHT ELBOW JOINT":
			index = 36;
			break;
			
		case "RIGHT WRIST":
			index = 35;
			break;
			
		case "LEFT WRIST":
			index = 32;
			break;
			
		case "RIGHT HAND":
			index = 23;
			break;
			
		case "LEFT HAND":
			index = 22;
			break;
			
		case "LEFT SHIN":
			index = 0;
			break;
			
		case "RIGHT SHIN":
			index = 3;
			break;
			
		case "LEFT KNEE JOINT":
			index = 2;
			break;
			
		case "RIGHT KNEE JOINT":
			index = 5;
			break;
			
		case "LEFT THIGH":
			index = 1;
			break;
			
		case "RIGHT THIGH":
			index = 4;
			break;
			
		case "LEFT FOOT":
			index = 38;
			break;
			
		case "RIGHT FOOT":
			index = 39;
			break;
			
		default:
			break;
		}
		
		return index;
	}
}

/************************************************************** 

-----------------------------
	     COLLIDERS:
-----------------------------
HEAD
NECK
ABDOMEN
CHEST
PELVIS
RIGHT SHOULDER
LEFT SHOULDER
RIGHT SHOULDER JOINT
LEFT SHOULDER JOINT
RIGHT FOREARM
LEFT FOREARM
LEFT ELBOW JOINT
RIGHT ELBOW JOINT
RIGHT WRIST
LEFT WRIST
RIGHT HAND
LEFT HAND
LEFT SHIN
RIGHT SHIN
LEFT KNEE JOINT
RIGHT KNEE JOINT
LEFT THIGH
RIGHT THIGH
LEFT FOOT
RIGHT FOOT

*************************************************************/
