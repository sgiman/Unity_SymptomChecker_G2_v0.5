﻿/*********************************************
  UI_Manager.cs
	Symptom Cheker (alpha)

DAZ	MALE+FEMALE

Writing by Sergey Gasanov, jun-aug,2015 
  version: 0.4
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class UI_Manager : MonoBehaviour 
{	
	public Camera cam; 				

	// MALE-FEMALE OBJECTS
	public GameObject daz_male;				// DAZ MALE		
	public GameObject daz_female;			// DAZ FEMALE
	public SkinnedMeshRenderer daz_mesh_ml;	// DAZ Model - male
	public SkinnedMeshRenderer daz_mesh_fm;	// DAZ Model - female
	public GameObject COLLIDERS_ML;			// Mesh collders for male 
	public GameObject COLLIDERS_FM; 		// Mesh collders for female
	public GameObject SLIDERS_ML;			// Body Sliders for male 
	public GameObject SLIDERS_FM; 		    // Body Sliders for female

	// Removal symptom 
	public GameObject R_SMPT1;
	public GameObject R_SMPT2;
	public GameObject R_SMPT3;
	public GameObject R_SMPT4;

	// ICONS GENDER 
	public GameObject I_MALE;		// Big icon for MALE	
	public GameObject I_FEMALE;		// Big icon for FRMALE
	public GameObject IND_MALE;	 	// Small icon for MALE
	public GameObject IND_FEMALE;	// Small icon for FEMALE

	// SIDEBAR PANELS
	public GameObject Basic; 
	public GameObject Body; 
	public GameObject Symptoms; 
	public GameObject Conditions; 

	// SIDEBAR MENU BUTTONS
	public Button b1;				// Button Menu Basic 
	public Button b2;				// Button Menu Body 
	public Button b3;				// Button Menu Symptoms 
	public Button b4;				// Button Menu Conditions 

	// BASIC DATA
	public Text TD_AGE; 
	public Text TD_HEIGHT; 
	public Text TD_WEIGHT; 

	public Toggle ToggleMale;				
	public Toggle ToggleFemale;				
	public Text t_gender; 				

	// SELECT 
	public Text T_BodyName;     	// SELECT PANEL - text "Name Body Parts"  
	public GameObject P_Select;		// SELECT PANEL - text "You Selected"	

	// BASIC CONTROL
	public Slider Weight;			// 5 - Weight
	public Text T_Weight;
	public Text T_Massa_Kg;

	public Slider Age;	 			// 47 - Age Face
	public Text T_Age;

	public Slider Height;			// 81 - Height
	public Text T_Height;   		// Santimeters  
	public Text T_Ft_Inch;			// Ft.Inch
	public Text T_BMI;				// BMI

	// BMI CHECKING
	public  GameObject Bmi_A;
	public  GameObject Bmi_B;
	public  GameObject Bmi_C;
	public  GameObject Bmi_D;

	public  Text BMI_AGE;
	public  Text BMI_HEIGHT;
	public  Text BMI_WEIGHT;

	public Slider SliderWeight;	

	// OPTIONS
	public Toggle Avatar;	
	public Toggle Info;	

	public GameObject INFO_BASIC;
	public GameObject INFO_BODY;
	public GameObject INFO_SYMPTOMS;

	// Working value
	private float hsm;
	private string fd;

	private float m;  
	private float h;
	private float bmi;
	private string massa_kg;
	private Material[] CasheMat_ml; 
	private Material[] CasheMat_fm; 


	void Start ()
	{
		cam.GetComponent<MOrbit_SG>().nx = 180.0f;
		cam.GetComponent<MOrbit_SG>().ny = 5.0f;
		cam.GetComponent<MOrbit_SG>().nz = 2.62f;
		ResetBasicSliders (); 		// Reset Basic Parameters

		CasheMat_ml = daz_mesh_ml.materials;
		CasheMat_fm = daz_mesh_fm.materials;

		Avatar.isOn = false;

		COLLIDERS_ML.SetActive (false);
		COLLIDERS_FM.SetActive (false);

		b1.interactable = false;
		b2.interactable = true;
		b3.interactable = true;
		b4.interactable = true;

		IND_MALE.SetActive(false);	
		IND_FEMALE.SetActive(false);	

	}


	void Update () 
	{
		float val;

		// Avatar OFF (1-Basic)
		if (Basic.activeSelf) 
		{
			Avatar.isOn = false;

			COLLIDERS_ML.SetActive (false); // Selection OFF
			COLLIDERS_FM.SetActive (false); // Selection OFF

			IND_MALE.SetActive(false);	
			IND_FEMALE.SetActive(false);	
			T_BodyName.text = "";			// SELECT PANEL - text "Name Body Parts"
			P_Select.SetActive(false);		// SELECT PANEL - text "You Selected"					
		
		}

		// Sliders for Male or Female (2-Body) 
		if (Body.activeSelf) 
		{
			if (ToggleMale.isOn)
			{
				SLIDERS_ML.SetActive(true);
				SLIDERS_FM.SetActive(false);
			}
			if (ToggleFemale.isOn)
			{
				SLIDERS_ML.SetActive(false);
				SLIDERS_FM.SetActive(true);
			}
		}

		if (Body.activeSelf || Symptoms.activeSelf || Conditions.activeSelf) 
		{
			if (ToggleMale.isOn)
			{
				IND_MALE.SetActive(true);	
				IND_FEMALE.SetActive(false);
			}
			else
			{
				IND_MALE.SetActive(false);	
				IND_FEMALE.SetActive(true);	
			}
		}

		// Select Panel
		if (T_BodyName.text == "" || 
			T_BodyName.text == "Mone") 
		{
			P_Select.SetActive(false);		// SELECT PANEL - text "You Selected"
			T_BodyName.text = "";			// SELECT PANEL - text "Name Body Parts"
		} 

		// 1 - GENDER
		if (ToggleMale.isOn) 
		{
			t_gender.text = "Male";
			I_MALE.SetActive(true) ;	
			I_FEMALE.SetActive(false);	
		} 
		else 
		{
			t_gender.text = "Female";
			I_MALE.SetActive(false) ;	
			I_FEMALE.SetActive(true);	
		}

		// 2 - AGE
		val = Age.value;
		T_Age.text = System.Math.Round(val, 0).ToString();

		// 3 - HEIGHT
		hsm = (float)System.Math.Round(Height.value, 2);
		T_Height.text = "(" + hsm.ToString() + " cm)";	// Height to Centimeters
		ConvertMetricToFD ();                          	// Convert Height to Ft.Inch
		T_Ft_Inch.text = fd;                           	// Height to Ft.Inch 

		// 3 - WEIGHT
		//val = (int)mr.GetPercent (5);
		val = Weight.value;
		float cor_fval = (val * 2.5f)+50.0f;
		int ival = (int) cor_fval;
		T_Weight.text = ival.ToString ();  		// Weight to LBS (pounds)

		//CALCULATE BMI - Body Mass Index
		m = (float)ival * 0.4536f; 				// PUNDS to KG  
		h = Height.value / 100.0f; 				// Height (sm) to meters 
		bmi = m / (h * h);						// Body Mass Index (BMI)
		T_BMI.text = System.Math.Round(bmi, 1).ToString();
		massa_kg = "(" + System.Math.Round(m, 0).ToString() + " kg)";
		T_Massa_Kg.text = massa_kg; 			// Weight to kg

		BmiCheck ();
		OptionsCheck ();

		TD_AGE.text = T_Age.text + " y.o."; 
		TD_HEIGHT.text = T_Ft_Inch.text; 
		TD_WEIGHT.text = T_Weight.text + " lbs"; 
		BMI_AGE.text = T_Age.text + " y.o.";
		BMI_HEIGHT.text = T_Ft_Inch.text;
		BMI_WEIGHT.text = T_Weight.text + " lbs";

	}

	/*------------------------
		     ResetSel
	------------------------*/
	public void ResetSel ()
	{	
		if (ToggleMale.isOn) 
		{
			daz_mesh_ml.materials = CasheMat_ml;
			COLLIDERS_ML.SetActive (true);
		}

		if (ToggleFemale.isOn) 
		{
			daz_mesh_fm.materials = CasheMat_fm;
			COLLIDERS_FM.SetActive (true);
		}

		T_BodyName.text = "";			// SELECT PANEL - text "Name Body Parts"
		P_Select.SetActive(false);		// SELECT PANEL - text "You Selected"

	}


	/**********************************************
				NAVIGATIONS (NEXT-BACK)
	 **********************************************/
	/*----------------------------
			1 - Next Basic 
	----------------------------*/
	public void  NextBasic()
	{
		Basic.SetActive (false); 
		Body.SetActive (true); 
		Symptoms.SetActive (false); 
		Conditions.SetActive (false); 

		b1.interactable = true;
		b2.interactable = false;
		b3.interactable = true;
		b4.interactable = true;

		Avatar.isOn = true;

		if (ToggleMale.isOn) {
			COLLIDERS_ML.SetActive (true);
			COLLIDERS_FM.SetActive (false);
		} 

		if (ToggleFemale.isOn) {
			COLLIDERS_ML.SetActive (false);
			COLLIDERS_ML.SetActive (true);
		}
	}		

	/*----------------------------
			2 - Next Body 
	----------------------------*/
	public void  NextBody()
	{
		Basic.SetActive(false); 
		Body.SetActive(false); 
		Symptoms.SetActive(true); 
		Conditions.SetActive(false); 

		b1.interactable = true;
		b2.interactable = true;
		b3.interactable = false;
		b4.interactable = true;

		Avatar.isOn = true;

		if (ToggleMale.isOn) {
			COLLIDERS_ML.SetActive (true);
			COLLIDERS_FM.SetActive (false);
		} 
		
		if (ToggleFemale.isOn) {
			COLLIDERS_ML.SetActive (false);
			COLLIDERS_ML.SetActive (true);
		}
	}

	/*----------------------------
			3 - Next Symptoms 
	----------------------------*/
	public void  NextSymptoms()
	{
		Basic.SetActive(false); 
		Body.SetActive(false); 
		Symptoms.SetActive(false); 
		Conditions.SetActive(true); 

		b1.interactable = true;
		b2.interactable = true;
		b3.interactable = true;
		b4.interactable = false;

		Avatar.isOn = true;

		if (ToggleMale.isOn) {
			COLLIDERS_ML.SetActive (true);
			COLLIDERS_FM.SetActive (false);
		} 
		
		if (ToggleFemale.isOn) {
			COLLIDERS_ML.SetActive (false);
			COLLIDERS_ML.SetActive (true);
		}

		R_SMPT1.SetActive(true);
		R_SMPT2.SetActive(true);
		R_SMPT3.SetActive(true);
		R_SMPT4.SetActive(true);
	}

	/*----------------------------
		    BACK-SYMPTOMS
	----------------------------*/
	public void  BackSymptoms()
	{
		Basic.SetActive(false); 
		Body.SetActive(true); 
		Symptoms.SetActive(false); 
		Conditions.SetActive(false); 

		b1.interactable = true;
		b2.interactable = false;
		b3.interactable = true;
		b4.interactable = true;

		Avatar.isOn = true;

		if (ToggleMale.isOn) {
			COLLIDERS_ML.SetActive (true);
			COLLIDERS_FM.SetActive (false);
		} 
		
		if (ToggleFemale.isOn) {
			COLLIDERS_ML.SetActive (false);
			COLLIDERS_ML.SetActive (true);
		}

	}

	/*----------------------------
		    BACK-Body
	----------------------------*/
	public void  BackBody()
	{
		Basic.SetActive(true); 
		Body.SetActive(false); 
		Symptoms.SetActive(false); 
		Conditions.SetActive(false); 
		
		b1.interactable = false;
		b2.interactable = true;
		b3.interactable = true;
		b4.interactable = true;
		
		Avatar.isOn = false;
		
		COLLIDERS_ML.SetActive (true);
		COLLIDERS_FM.SetActive (false);

	}

	/*----------------------------
		  BACK-CONDITIONS
	----------------------------*/
	public void  BackCond()
	{
		Basic.SetActive(false); 
		Body.SetActive(false); 
		Symptoms.SetActive(true); 
		Conditions.SetActive(false); 

		b1.interactable = true;
		b2.interactable = true;
		b3.interactable = false;
		b4.interactable = true;

		Avatar.isOn = true;

		if (ToggleMale.isOn) {
			COLLIDERS_ML.SetActive (true);
			COLLIDERS_FM.SetActive (false);
		} 
		
		if (ToggleFemale.isOn) {
			COLLIDERS_ML.SetActive (false);
			COLLIDERS_ML.SetActive (true);
		}
	}

	/*----------------------------
	           AvatarOn()
	----------------------------*/
	public void  AvatarOn()
	{
		// Avatar ON (for others) 
	    if (Body.activeSelf || Symptoms.activeSelf || Conditions.activeSelf) 
		{
			Avatar.isOn = true;

			if (ToggleMale.isOn) {
				COLLIDERS_ML.SetActive (true);
				COLLIDERS_FM.SetActive (false);
			} 
			
			if (ToggleFemale.isOn) {
				COLLIDERS_ML.SetActive (false);
				COLLIDERS_ML.SetActive (true);
			}
		}
	}

	/*----------------------------
	           BmiCheck()
	----------------------------*/
	public void  BmiCheck()
	{
		if (bmi < 18.5) 
		{
			Bmi_A.SetActive(true);
			Bmi_B.SetActive(false);
			Bmi_C.SetActive(false);
			Bmi_D.SetActive(false);
		}

		if (bmi >= 18.5 && bmi <= 25) 
		{
			Bmi_A.SetActive(false);
			Bmi_B.SetActive(true);
			Bmi_C.SetActive(false);
			Bmi_D.SetActive(false);
		}

		if (bmi >= 25 && bmi <= 30) 
		{
			Bmi_A.SetActive(false);
			Bmi_B.SetActive(false);
			Bmi_C.SetActive(true);
			Bmi_D.SetActive(false);
		}
		if (bmi > 30) 
		{
			Bmi_A.SetActive(false);
			Bmi_B.SetActive(false);
			Bmi_C.SetActive(false);
			Bmi_D.SetActive(true);
		}
	
	}

	/*----------------------------
		  Reset Basic Sliders
	----------------------------*/
	public void ResetBasicSliders () 
	{
		Weight.value = 20;	 		
		Age.value = 21;	 		
		T_Height.text = "(170 cm)";
		Height.value = 170;
		t_gender.text = "Male";
	}


	/****************************
		   MENU BUTTONS
	****************************/
	public void MenuClick_b1 ()		// B1 - BASIC
	{
		b1.interactable = false;
		b2.interactable = true;
		b3.interactable = true;
		b4.interactable = true;

		Basic.SetActive(true);
		Body.SetActive(false);
		Symptoms.SetActive(false);
		Conditions.SetActive(false);

		daz_male.SetActive(false);	
		daz_female.SetActive(false);	
	}

	public void MenuClick_b2 ()		// B2 - BODY
	{
		
		b1.interactable = true;
		b2.interactable = false;
		b3.interactable = true;
		b4.interactable = true;

		Basic.SetActive(false);
		Body.SetActive(true);
		Symptoms.SetActive(false);
		Conditions.SetActive(false);
	}

	public void MenuClick_b3 ()		// B3 - SYMPTOMS
	{	
		b1.interactable = true;
		b2.interactable = true;
		b3.interactable = false;
		b4.interactable = true;

		Basic.SetActive(false);
		Body.SetActive(false);
		Symptoms.SetActive(true);
		Conditions.SetActive(false);
	}

	public void MenuClick_b4 ()		// B4 - CONDITIONS
	{		
		b1.interactable = true;
		b2.interactable = true;
		b3.interactable = true;
		b4.interactable = false;

		Basic.SetActive(false);
		Body.SetActive(false);
		Symptoms.SetActive(false);
		Conditions.SetActive(true);

		R_SMPT1.SetActive(true);
		R_SMPT2.SetActive(true);
		R_SMPT3.SetActive(true);
		R_SMPT4.SetActive(true);
	}


	/*----------------------------
	  	    OptionsCheck
	----------------------------*/
	public void OptionsCheck ()
	{
		// AVATAR ON-OFF
		if (Avatar.isOn) 
		{
			if (ToggleMale.isOn)
			{
				daz_male.SetActive (true);
				daz_female.SetActive (false);
			}

			if (ToggleFemale.isOn)
			{
				daz_male.SetActive (false);
				daz_female.SetActive (true);
			}

			if (ToggleMale.isOn)
			{
				COLLIDERS_ML.SetActive (true);
				COLLIDERS_FM.SetActive (false);
			}

			if (ToggleFemale.isOn)
			{
				COLLIDERS_ML.SetActive (false);
				COLLIDERS_FM.SetActive (true);
			}
		} 
		else 
		{
			daz_male.SetActive (false);
			daz_female.SetActive (false);
			COLLIDERS_ML.SetActive (false);
			COLLIDERS_FM.SetActive (false);
		}

		// IF MALE (check correct)
		if (ToggleMale.isOn) 
			if (daz_male.activeSelf) 
			{
				Avatar.isOn = true;
				COLLIDERS_ML.SetActive (true);
				COLLIDERS_FM.SetActive (false);
			} 
			else 
			{
				Avatar.isOn = false;
				COLLIDERS_ML.SetActive (false);
				COLLIDERS_FM.SetActive (true);
			}

		// If FEMALE (check correct)
		if (ToggleFemale.isOn) 
			if (daz_female.activeSelf) 
			{
				Avatar.isOn = true;
				COLLIDERS_FM.SetActive (true);
				COLLIDERS_ML.SetActive (false);
			} 
			else
			{
				Avatar.isOn = false;
				COLLIDERS_FM.SetActive (true);
				COLLIDERS_ML.SetActive (false);
			}


		// INFO ON-OFF
		if (Info.isOn) 
		{	
			INFO_BASIC.SetActive (true);
			INFO_BODY.SetActive (true);
			INFO_SYMPTOMS.SetActive (true);
		} else 
		{
			INFO_BASIC.SetActive (false);
			INFO_BODY.SetActive (false);
			INFO_SYMPTOMS.SetActive (false);
		}

	}
	
	/*----------------------------
				Exit
	----------------------------*/
	public void Exit ()
	{
		Application.Quit(); 
		Debug.Log ("EXIT... ");
	}

	/*--------------------------------
	    Convert Metric to Ft.Inch
	---------------------------------*/
	public void ConvertMetricToFD ()
	{
		int hi;
		hi = Mathf.CeilToInt (Height.value); // FLOAT to INT 

		switch (hi) 
		{

		case 149:	fd = "4\' 11\"";	break;
		
		case 150:	fd = "4\' 11\"";	break;
		case 151:	fd = "4\' 11\"";	break;
		case 152:	fd = "5\' 0\"";		break;
		case 153:	fd = "5\' 0\"";		break;
		case 154:	fd = "5\' 1\"";		break;
		case 155:	fd = "5\' 1\"";		break;
		case 156:	fd = "5\' 1\"";		break;
		case 157:	fd = "5\' 2\"";		break;
		case 158:	fd = "5\' 2\"";		break;
		case 159:	fd = "5\' 3\"";		break;
		
		case 160:	fd = "5\' 3\"";		break;
		case 161:	fd = "5\' 3\"";		break;
		case 162:	fd = "5\' 4\"";		break;
		case 163:	fd = "5\' 4\"";		break;
		case 164:	fd = "5\' 4\"";		break;
		case 165:	fd = "5\' 5\"";		break;
		case 166:	fd = "5\' 5\"";		break;
		case 167:	fd = "5\' 6\"";		break;
		case 168:	fd = "5\' 6\"";		break;
		case 169:	fd = "5\' 7\"";		break;
		
		case 170:	fd = "5\' 7\"";		break;
		case 171:	fd = "5\' 7\"";		break;
		case 172:	fd = "5\' 8\"";		break;
		case 173:	fd = "5\' 8\"";		break;
		case 174:	fd = "5\' 8\"";		break;
		case 175:	fd = "5\' 9\"";		break;
		case 176:	fd = "5\' 9\"";		break;
		case 177:	fd = "5\' 10\"";	break;
		case 178:	fd = "5\' 10\"";	break;
		case 179:	fd = "5\' 10\"";	break;
		
		case 180:	fd = "5\' 11\"";	break;
		case 181:	fd = "5\' 11\"";	break;
		case 182:	fd = "6\' 0\"";		break;
		case 183:	fd = "6\' 0\"";		break;
		case 184:	fd = "6\' 0\"";		break;
		case 185:	fd = "6\' 1\"";		break;
		case 186:	fd = "6\' 1\"";		break;
		case 187:	fd = "6\' 2\"";		break;
		case 188:	fd = "6\' 2\"";		break;
		case 189:	fd = "6\' 2\"";		break;
		
		case 190:	fd = "6\' 3\"";		break;
		case 191:	fd = "6\' 3\"";		break;
		case 192:	fd = "6\' 4\"";		break;
		case 193:	fd = "6\' 4\"";		break;
		case 194:	fd = "6\' 4\"";		break;
		case 195:	fd = "6\' 5\"";		break;
		case 196:	fd = "6\' 5\"";		break;
		case 197:	fd = "6\' 5\"";		break;
		case 198:	fd = "6\' 6\"";		break;
		case 199:	fd = "6\' 6\"";		break;
		
		case 200:	fd = "6\' 7\"";		break;
		case 201:	fd = "6\' 7\"";		break;
		case 202:	fd = "6\' 7\"";		break;
		case 203:	fd = "6\' 8\"";		break;
		case 204:	fd = "6\' 8\"";		break;
		case 205:	fd = "6\' 9\"";		break;
		case 206:	fd = "6\' 9\"";		break;
		case 207:	fd = "6\' 9\"";		break;
		case 208:	fd = "6\' 10\"";	break;
		case 209:	fd = "6\' 10\"";	break;
		case 210:	fd = "6\' 11\"";	break;

		default:
		break;
		}
	}


}
