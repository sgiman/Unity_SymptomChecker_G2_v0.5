﻿/*********************************************
  BodySliders.cs
	Symptom Cheker (alpha)

 MALE + FEMALE

 Writing by Sergey Gasanov, aug,2015 
 version: 0.5
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class BodySliders : MonoBehaviour 
{
	public GameObject daz_male;		
	public GameObject daz_female;		

	// DAZ MALE MORPHS
	public Slider NeckWeight_ml;		// 44 - Neck
	public Slider ArmsLength_ml;		// 4  - Arm Length		
	public Slider RibcageSize_ml;		// 63 - Chest			
	public Slider WaistSize_ml;			// 11 - Waist	
	public Slider HipWidth_ml;			// 23 - Hip Width
	public Slider Height_ml;			// 81 - Height

	// DAZ FEMALE MORPHS
	public Slider NeckSize_fm;		// 45	- Neck Size
	public Slider ArmsLength_fm;	// 6 	- Arm Length		
	public Slider ChestSize_fm;		// 5 	- Chest Size			
	public Slider WaistWight_fm;	// 37 	- Waist Wight	
	public Slider HipSize_fm;		// 49	- Hip Size
	public Slider BreastSize_fm;	// 75	- Breast Size
	public Slider LegsLength_fm;	// 47	- Legs Length


	void Update () 
	{
		int val;

		// Setup morphs for MALE 
		MegaMorph mr_ml = daz_male.GetComponent<MegaMorph> ();
		val = (int)mr_ml.GetPercent (44);	// Neck
		val = (int)mr_ml.GetPercent (4);	// Arm Length
		val = (int)mr_ml.GetPercent (63);	// Chest
		val = (int)mr_ml.GetPercent (11);	// Weist
		val = (int)mr_ml.GetPercent (23);	// Hip
		val = (int)mr_ml.GetPercent (81);	// Height

		// Setup morphs for FEMALE 
		MegaMorph mr_fm = daz_male.GetComponent<MegaMorph> ();
		val = (int)mr_fm.GetPercent (45);	// Neck Size
		val = (int)mr_fm.GetPercent (6);	// Arm Length
		val = (int)mr_fm.GetPercent (5);	// Chest Size
		val = (int)mr_fm.GetPercent (37);	// Waist Wight
		val = (int)mr_fm.GetPercent (49);	// Hip Size
		val = (int)mr_fm.GetPercent (75);	// Breast Size
		val = (int)mr_fm.GetPercent (47);	// Legs Length

	}


	/*----------------------------
	  Set Body Sliders for MALE
	----------------------------*/
	public void  SetBodySliders_ML()
	{
		// Num & Array names morphs channels  
		MegaMorph mr_ml = daz_male.GetComponent<MegaMorph>();
		int num = mr_ml.NumChannels();
		string[] names = new string[num];
		names = mr_ml.GetChannelNames(); 
		
		mr_ml.SetPercent (44, NeckWeight_ml.value);	 		
		mr_ml.SetPercent (4,  ArmsLength_ml.value);	 		
		mr_ml.SetPercent (63, RibcageSize_ml.value);	 		
		mr_ml.SetPercent (11, WaistSize_ml.value);
		mr_ml.SetPercent (23, HipWidth_ml.value);
		mr_ml.SetPercent (81, Height_ml.value);
	}

	/*-----------------------------
	  Set Body Sliders for FEMALE
	-----------------------------*/
	public void  SetBodySliders_FM()
	{
		// Num & Array names morphs channels  
		MegaMorph mr_fm = daz_female.GetComponent<MegaMorph>();
		int num = mr_fm.NumChannels();
		string[] names = new string[num];
		names = mr_fm.GetChannelNames(); 
		
		mr_fm.SetPercent (45, NeckSize_fm.value);	 		
		mr_fm.SetPercent (6,  ArmsLength_fm.value);	 		
		mr_fm.SetPercent (5,  ChestSize_fm.value);	 		
		mr_fm.SetPercent (37, WaistWight_fm.value);
		mr_fm.SetPercent (49, HipSize_fm.value);
		mr_fm.SetPercent (75, BreastSize_fm.value);
		mr_fm.SetPercent (47, LegsLength_fm.value);

	}

	/*------------------------------
	    Reset Body Sliders (ALL)
	------------------------------*/
	public void ResetBodySliders () 
	{

		// RESET MORRPS MALE
		// Num & Array names morphs channels  
		MegaMorph mr_ml = daz_male.GetComponent<MegaMorph> ();

		mr_ml.SetPercent (44, 0);	 		
		mr_ml.SetPercent (4,  0);	 		
		mr_ml.SetPercent (63, 0);	 		
		mr_ml.SetPercent (11, 0);
		mr_ml.SetPercent (23, 0);
		mr_ml.SetPercent (81, 0);

		NeckWeight_ml.value = 0;	 		
		ArmsLength_ml.value = 0;			
		RibcageSize_ml.value = 0;				
		WaistSize_ml.value = 0;			
		HipWidth_ml.value = 0;			
		Height_ml.value = 0;			

		// RESET MORRPS FEMALE
		// Num & Array names morphs channels  
		MegaMorph mr_fm = daz_female.GetComponent<MegaMorph> ();
		
		mr_fm.SetPercent (45, 0);	 		
		mr_fm.SetPercent (6,  0);	 		
		mr_fm.SetPercent (5,  0);	 		
		mr_fm.SetPercent (37, 0);
		mr_fm.SetPercent (49, 0);
		mr_fm.SetPercent (75, 0);
		mr_fm.SetPercent (47, 0);

		NeckSize_fm.value = 0;	 		
		ArmsLength_fm.value = 0;	 		
		ChestSize_fm.value = 0;	 		
		WaistWight_fm.value =0;
		HipSize_fm.value = 0;
		BreastSize_fm.value = 0;
		LegsLength_fm.value = 0;
	}


}
