﻿/*********************************************
  Symptoms_Quiz_Cond.cs
	Symptom Cheker (alpha)

  Writing by Sergey Gasanov, aug,2015 
  version: 0.5
*********************************************/
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Symptoms_Quiz_Cond : MonoBehaviour 
{
	public GameObject COLLIDERS_ML;
	public GameObject COLLIDERS_FM;
	public GameObject BASIC; 
	public GameObject BODY; 
	public GameObject CONDITIONS; 
	public GameObject SYMPTOMS; 

	// ---------------------------- 
	// HEAD SYMPTOMS 
	//----------------------------- 
	// Info panels
	public GameObject I_HEAD1;
	public GameObject I_HEAD2;
	public GameObject I_HEAD3;
	public GameObject I_HEAD4;
	public GameObject I_HEAD5;

	// Quiz panels
	public GameObject Q_HEAD1;
	public GameObject Q_HEAD2;
	public GameObject Q_HEAD3;
	public GameObject Q_HEAD4;
	public GameObject Q_HEAD5;

	// ---------------------------- 
	// NECK SYMPTOMS 
	//----------------------------- 
	// Info panels
	public GameObject I_NECK1;
	public GameObject I_NECK2;
	public GameObject I_NECK3;
	public GameObject I_NECK4;
	public GameObject I_NECK5;
	
	// Quiz panels
	public GameObject Q_NECK1;
	public GameObject Q_NECK2;
	public GameObject Q_NECK3;
	public GameObject Q_NECK4;
	public GameObject Q_NECK5;

	// ---------------------------- 
	// CHEST SYMPTOMS 
	//----------------------------- 
	// Info panels
	public GameObject I_CHEST1;
	public GameObject I_CHEST2;
	public GameObject I_CHEST3;
	public GameObject I_CHEST4;
	public GameObject I_CHEST5;

	// Quiz panels
	public GameObject Q_CHEST1;
	public GameObject Q_CHEST2;
	public GameObject Q_CHEST3;
	public GameObject Q_CHEST4;
	public GameObject Q_CHEST5;

	// ---------------------------- 
	// ABDOMEN SYMPTOMS 
	//----------------------------- 
	// Info panels
	public GameObject I_ABDOMEN1;
	public GameObject I_ABDOMEN2;
	public GameObject I_ABDOMEN3;
	public GameObject I_ABDOMEN4;
	public GameObject I_ABDOMEN5;
	
	// Quiz panels
	public GameObject Q_ABDOMEN1;
	public GameObject Q_ABDOMEN2;
	public GameObject Q_ABDOMEN3;
	public GameObject Q_ABDOMEN4;
	public GameObject Q_ABDOMEN5;

	// ---------------------------- 
	// PELVIS SYMPTOMS 
	//----------------------------- 
	// Info panels
	public GameObject I_PELVIS1;
	public GameObject I_PELVIS2;
	public GameObject I_PELVIS3;
	public GameObject I_PELVIS4;
	public GameObject I_PELVIS5;

	// Quiz panels
	public GameObject Q_PELVIS1;
	public GameObject Q_PELVIS2;
	public GameObject Q_PELVIS3;
	public GameObject Q_PELVIS4;
	public GameObject Q_PELVIS5;

	// ---------------------------- 
	// LEGS SYMPTOMS
	//----------------------------- 
	// Info panels
	public GameObject I_LEGS1;
	public GameObject I_LEGS2;
	public GameObject I_LEGS3;
	public GameObject I_LEGS4;
	public GameObject I_LEGS5;

	// Quiz panels
	public GameObject Q_LEGS1;
	public GameObject Q_LEGS2;
	public GameObject Q_LEGS3;
	public GameObject Q_LEGS4;
	public GameObject Q_LEGS5;


	// ---------------------------- 
	// HANDS SYMPTOMS 
	//----------------------------- 
	// Info panels
	public GameObject I_HANDS1;
	public GameObject I_HANDS2;
	public GameObject I_HANDS3;
	public GameObject I_HANDS4;
	public GameObject I_HANDS5;

	// Quiz panels
	public GameObject Q_HANDS1;
	public GameObject Q_HANDS2;
	public GameObject Q_HANDS3;
	public GameObject Q_HANDS4;
	public GameObject Q_HANDS5;


	// ---------------------------- 
	// SHOULDERS SYMPTOMS 
	//----------------------------- 
	// Info panels
	public GameObject I_SHOULDERS1;
	public GameObject I_SHOULDERS2;
	public GameObject I_SHOULDERS3;
	public GameObject I_SHOULDERS4;
	public GameObject I_SHOULDERS5;
	public GameObject I_SHOULDERS6;
	public GameObject I_SHOULDERS7;

	// Quiz panels
	public GameObject Q_SHOULDERS1;
	public GameObject Q_SHOULDERS2;
	public GameObject Q_SHOULDERS3;
	public GameObject Q_SHOULDERS4;
	public GameObject Q_SHOULDERS5;
	public GameObject Q_SHOULDERS6;
	public GameObject Q_SHOULDERS7;

	// ---------------------------- 
	// GENERAL SYMPTOMS 
	//----------------------------- 
	// Info panels
	public GameObject I_GENERAL1;
	public GameObject I_GENERAL2;
	public GameObject I_GENERAL3;
	public GameObject I_GENERAL4;
	public GameObject I_GENERAL5;
	public GameObject I_GENERAL6;
	public GameObject I_GENERAL7;
	public GameObject I_GENERAL8;
	public GameObject I_GENERAL9;
	public GameObject I_GENERAL10;
	public GameObject I_GENERAL11;
	public GameObject I_GENERAL12;
	public GameObject I_GENERAL13;
	public GameObject I_GENERAL14;
	public GameObject I_GENERAL15;
	public GameObject I_GENERAL16;
	public GameObject I_GENERAL17;
	public GameObject I_GENERAL18;
	public GameObject I_GENERAL19;
	public GameObject I_GENERAL20;
	public GameObject I_GENERAL21;
	public GameObject I_GENERAL22;
	public GameObject I_GENERAL23;
	public GameObject I_GENERAL24;
	public GameObject I_GENERAL25;
	public GameObject I_GENERAL26;
	public GameObject I_GENERAL27;
	public GameObject I_GENERAL28;
	public GameObject I_GENERAL29;
	public GameObject I_GENERAL30;
	public GameObject I_GENERAL31;
	public GameObject I_GENERAL32;
	public GameObject I_GENERAL33;

	// Quiz panels
	public GameObject Q_GENERAL1;  // Quiz General 1-3 (3 pages)
	public GameObject Q_GENERAL2;
	public GameObject Q_GENERAL3;
	public GameObject Q_GENERAL4;
	public GameObject Q_GENERAL5;
	public GameObject Q_GENERAL6;
	public GameObject Q_GENERAL7;
	public GameObject Q_GENERAL8;
	public GameObject Q_GENERAL9;
	public GameObject Q_GENERAL10;
	public GameObject Q_GENERAL11;
	public GameObject Q_GENERAL12;
	public GameObject Q_GENERAL13;
	public GameObject Q_GENERAL14;
	public GameObject Q_GENERAL15;
	public GameObject Q_GENERAL16;
	public GameObject Q_GENERAL17;
	public GameObject Q_GENERAL18;
	public GameObject Q_GENERAL19;
	public GameObject Q_GENERAL20;
	public GameObject Q_GENERAL21;
	public GameObject Q_GENERAL22;
	public GameObject Q_GENERAL23;
	public GameObject Q_GENERAL24;
	public GameObject Q_GENERAL25;
	public GameObject Q_GENERAL26;
	public GameObject Q_GENERAL27;
	public GameObject Q_GENERAL28;
	public GameObject Q_GENERAL29;
	public GameObject Q_GENERAL30;
	public GameObject Q_GENERAL31;
	public GameObject Q_GENERAL32;
	public GameObject Q_GENERAL33;

	// Quiz panels NEXT
	public GameObject Q_GENERAL_2_3;
	public GameObject Q_GENERAL_3_3;

	public GameObject Q_HEAD_2_3;
	public GameObject Q_HEAD_3_3;

	public GameObject Q_NECK_2_3;
	public GameObject Q_NECK_3_3;

	public GameObject Q_CHEST_2_3;
	public GameObject Q_CHEST_3_3;

	public GameObject Q_ABDOMEN_2_3;
	public GameObject Q_ABDOMEN_3_3;

	public GameObject Q_PELVIS_2_3;
	public GameObject Q_PELVIS_3_3;

	public GameObject Q_LEGS_2_3;
	public GameObject Q_LEGS_3_3;

	public GameObject Q_HANDS_2_3;
	public GameObject Q_HANDS_3_3;

	// CONDITIONS PANELS
	public GameObject C_COND1;
	public GameObject C_COND2;
	public GameObject C_COND3;
	public GameObject C_COND4;
	public GameObject C_COND5;


	void Update () 
	{
		//-----------------------------
		//	DISABLE-ENABLE SELECT
		//-----------------------------
		if (Q_SHOULDERS1.activeSelf || 
			Q_SHOULDERS2.activeSelf ||
			Q_SHOULDERS3.activeSelf ||
			Q_SHOULDERS4.activeSelf ||
			Q_SHOULDERS5.activeSelf ||
			Q_SHOULDERS6.activeSelf ||
			Q_SHOULDERS7.activeSelf ||
			
			Q_GENERAL1.activeSelf || 
			Q_GENERAL2.activeSelf || 
			Q_GENERAL3.activeSelf || 
			Q_GENERAL4.activeSelf || 
			Q_GENERAL5.activeSelf || 
			Q_GENERAL6.activeSelf || 
			Q_GENERAL7.activeSelf || 
			Q_GENERAL8.activeSelf || 
			Q_GENERAL9.activeSelf || 
			Q_GENERAL10.activeSelf || 
			Q_GENERAL11.activeSelf || 
			Q_GENERAL12.activeSelf || 
			Q_GENERAL13.activeSelf || 
			Q_GENERAL14.activeSelf || 
			Q_GENERAL15.activeSelf ||
		    Q_GENERAL16.activeSelf ||
		    Q_GENERAL17.activeSelf ||
		    Q_GENERAL18.activeSelf ||
		    Q_GENERAL19.activeSelf ||
		    Q_GENERAL20.activeSelf ||
		    Q_GENERAL21.activeSelf ||
		    Q_GENERAL22.activeSelf ||
		    Q_GENERAL23.activeSelf ||
		    Q_GENERAL24.activeSelf ||
		    Q_GENERAL25.activeSelf ||
		    Q_GENERAL26.activeSelf ||
		    Q_GENERAL27.activeSelf ||
		    Q_GENERAL28.activeSelf ||
		    Q_GENERAL29.activeSelf ||
		    Q_GENERAL30.activeSelf ||
		    Q_GENERAL31.activeSelf ||
		    Q_GENERAL32.activeSelf ||
		    Q_GENERAL33.activeSelf ||

			Q_HEAD1.activeSelf || 
			Q_HEAD2.activeSelf || 
			Q_HEAD3.activeSelf || 
			Q_HEAD4.activeSelf || 
			Q_HEAD5.activeSelf || 

			Q_NECK1.activeSelf || 
			Q_NECK2.activeSelf || 
			Q_NECK3.activeSelf || 
			Q_NECK4.activeSelf || 
			Q_NECK5.activeSelf || 

			Q_CHEST1.activeSelf || 
			Q_CHEST2.activeSelf || 
			Q_CHEST3.activeSelf || 
			Q_CHEST4.activeSelf || 
			Q_CHEST5.activeSelf || 

			Q_ABDOMEN1.activeSelf || 
			Q_ABDOMEN2.activeSelf || 
			Q_ABDOMEN3.activeSelf || 
			Q_ABDOMEN4.activeSelf || 
			Q_ABDOMEN5.activeSelf || 

			Q_PELVIS1.activeSelf || 
			Q_PELVIS2.activeSelf || 
			Q_PELVIS3.activeSelf || 
			Q_PELVIS4.activeSelf || 
			Q_PELVIS5.activeSelf || 

			Q_LEGS1.activeSelf || 
			Q_LEGS2.activeSelf || 
			Q_LEGS3.activeSelf || 
			Q_LEGS4.activeSelf || 
			Q_LEGS5.activeSelf || 

			Q_HANDS1.activeSelf || 
			Q_HANDS2.activeSelf || 
			Q_HANDS3.activeSelf || 
			Q_HANDS4.activeSelf || 
			Q_HANDS5.activeSelf || 

			C_COND1.activeSelf ||
			C_COND2.activeSelf ||
			C_COND3.activeSelf ||
			C_COND4.activeSelf ||
			C_COND5.activeSelf ||

			Q_GENERAL_2_3.activeSelf ||
			Q_GENERAL_3_3.activeSelf ||
			Q_HEAD_2_3.activeSelf ||
			Q_HEAD_3_3.activeSelf ||
			Q_NECK_2_3.activeSelf ||
			Q_NECK_3_3.activeSelf || 
			Q_CHEST_2_3.activeSelf ||
			Q_CHEST_3_3.activeSelf ||
			Q_ABDOMEN_2_3.activeSelf ||
			Q_ABDOMEN_3_3.activeSelf ||
			Q_PELVIS_2_3.activeSelf ||
			Q_PELVIS_3_3.activeSelf || 
			Q_LEGS_2_3.activeSelf ||
			Q_LEGS_3_3.activeSelf ||
			Q_HANDS_2_3.activeSelf ||
			Q_HANDS_3_3.activeSelf ||

			BASIC.activeSelf 

		    ) 
		{
			COLLIDERS_ML.SetActive (false);
			COLLIDERS_FM.SetActive (false);
		}


		if (BASIC.activeSelf || BODY.activeSelf || CONDITIONS.activeSelf) 
			QUIZ_CLOSE_ALL();

		if (BASIC.activeSelf || BODY.activeSelf || SYMPTOMS.activeSelf) 
			SYMPT_CLOSE_ALL();

	}

	//----------------------------
	//     INFO CLOSE ALL
	//----------------------------
	void INFO_CLOSE_ALL()
	{
		I_SHOULDERS1.SetActive(false);   
		I_SHOULDERS2.SetActive(false);
		I_SHOULDERS3.SetActive(false);
		I_SHOULDERS4.SetActive(false);
		I_SHOULDERS5.SetActive(false);
		I_SHOULDERS6.SetActive(false);
		I_SHOULDERS7.SetActive(false);
		
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false); 
		I_GENERAL3.SetActive(false); 
		I_GENERAL4.SetActive(false); 
		I_GENERAL5.SetActive(false); 
		I_GENERAL6.SetActive(false); 
		I_GENERAL7.SetActive(false); 
		I_GENERAL8.SetActive(false); 
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false); 
		I_GENERAL11.SetActive(false); 
		I_GENERAL12.SetActive(false); 
		I_GENERAL13.SetActive(false); 
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);

		I_HEAD1.SetActive(false); 
		I_HEAD2.SetActive(false); 
		I_HEAD3.SetActive(false); 
		I_HEAD4.SetActive(false); 
		I_HEAD5.SetActive(false); 
		
		I_NECK1.SetActive(false); 
		I_NECK2.SetActive(false); 
		I_NECK3.SetActive(false); 
		I_NECK4.SetActive(false); 
		I_NECK5.SetActive(false); 
		
		I_CHEST1.SetActive(false); 
		I_CHEST2.SetActive(false); 
		I_CHEST3.SetActive(false); 
		I_CHEST4.SetActive(false); 
		I_CHEST5.SetActive(false); 
		
		I_ABDOMEN1.SetActive(false); 
		I_ABDOMEN2.SetActive(false); 
		I_ABDOMEN3.SetActive(false); 
		I_ABDOMEN4.SetActive(false); 
		I_ABDOMEN5.SetActive(false); 
		
		I_PELVIS1.SetActive(false); 
		I_PELVIS2.SetActive(false); 
		I_PELVIS3.SetActive(false);
		I_PELVIS4.SetActive(false); 
		I_PELVIS5.SetActive(false); 
		
		I_LEGS1.SetActive(false); 
		I_LEGS2.SetActive(false); 
		I_LEGS3.SetActive(false); 
		I_LEGS4.SetActive(false); 
		I_LEGS5.SetActive(false); 
		
		I_HANDS1.SetActive(false); 
		I_HANDS2.SetActive(false); 
		I_HANDS3.SetActive(false); 
		I_HANDS4.SetActive(false); 
		I_HANDS5.SetActive(false); 
		
	}

	//----------------------------
	//     SYMPTOMS CLOSE ALL
	//----------------------------
	void SYMPT_CLOSE_ALL()
	{
		C_COND1.SetActive(false);
		C_COND2.SetActive(false);
		C_COND3.SetActive(false);
		C_COND4.SetActive(false);
		C_COND5.SetActive(false);
	}

	//----------------------------
	//     QUIZ CLOSE ALL
	//----------------------------
	public void QUIZ_CLOSE_ALL()
	{
		Q_SHOULDERS1.SetActive(false);   
		Q_SHOULDERS2.SetActive(false);
		Q_SHOULDERS3.SetActive(false);
		Q_SHOULDERS4.SetActive(false);
		Q_SHOULDERS5.SetActive(false);
		Q_SHOULDERS6.SetActive(false);
		Q_SHOULDERS7.SetActive(false);
		    
		I_SHOULDERS1.SetActive(false);   
		I_SHOULDERS2.SetActive(false);
		I_SHOULDERS3.SetActive(false);
		I_SHOULDERS4.SetActive(false);
		I_SHOULDERS5.SetActive(false);
		I_SHOULDERS6.SetActive(false);
		I_SHOULDERS7.SetActive(false);

		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false); 
		Q_GENERAL3.SetActive(false); 
		Q_GENERAL4.SetActive(false); 
		Q_GENERAL5.SetActive(false); 
		Q_GENERAL6.SetActive(false); 
		Q_GENERAL7.SetActive(false); 
		Q_GENERAL8.SetActive(false); 
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false); 
		Q_GENERAL11.SetActive(false); 
		Q_GENERAL12.SetActive(false); 
		Q_GENERAL13.SetActive(false); 
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);


		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false); 
		I_GENERAL3.SetActive(false); 
		I_GENERAL4.SetActive(false); 
		I_GENERAL5.SetActive(false); 
		I_GENERAL6.SetActive(false); 
		I_GENERAL7.SetActive(false); 
		I_GENERAL8.SetActive(false); 
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false); 
		I_GENERAL11.SetActive(false); 
		I_GENERAL12.SetActive(false); 
		I_GENERAL13.SetActive(false); 
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);

		Q_HEAD1.SetActive(false); 
		Q_HEAD2.SetActive(false); 
		Q_HEAD3.SetActive(false); 
		Q_HEAD4.SetActive(false); 
		Q_HEAD5.SetActive(false); 
		    
		I_HEAD1.SetActive(false); 
		I_HEAD2.SetActive(false); 
		I_HEAD3.SetActive(false); 
		I_HEAD4.SetActive(false); 
		I_HEAD5.SetActive(false); 

		Q_NECK1.SetActive(false); 
		Q_NECK2.SetActive(false); 
		Q_NECK3.SetActive(false); 
		Q_NECK4.SetActive(false); 
		Q_NECK5.SetActive(false); 

		I_NECK1.SetActive(false); 
		I_NECK2.SetActive(false); 
		I_NECK3.SetActive(false); 
		I_NECK4.SetActive(false); 
		I_NECK5.SetActive(false); 

		Q_CHEST1.SetActive(false); 
		Q_CHEST2.SetActive(false); 
		Q_CHEST3.SetActive(false); 
		Q_CHEST4.SetActive(false); 
		Q_CHEST5.SetActive(false); 
		    
		I_CHEST1.SetActive(false); 
		I_CHEST2.SetActive(false); 
		I_CHEST3.SetActive(false); 
		I_CHEST4.SetActive(false); 
		I_CHEST5.SetActive(false); 

		Q_ABDOMEN1.SetActive(false); 
		Q_ABDOMEN2.SetActive(false); 
		Q_ABDOMEN3.SetActive(false); 
		Q_ABDOMEN4.SetActive(false); 
		Q_ABDOMEN5.SetActive(false); 
		    
		I_ABDOMEN1.SetActive(false); 
		I_ABDOMEN2.SetActive(false); 
		I_ABDOMEN3.SetActive(false); 
		I_ABDOMEN4.SetActive(false); 
		I_ABDOMEN5.SetActive(false); 

		Q_PELVIS1.SetActive(false); 
		Q_PELVIS2.SetActive(false); 
		Q_PELVIS3.SetActive(false);
		Q_PELVIS4.SetActive(false); 
		Q_PELVIS5.SetActive(false); 
		    
		I_PELVIS1.SetActive(false); 
		I_PELVIS2.SetActive(false); 
		I_PELVIS3.SetActive(false);
		I_PELVIS4.SetActive(false); 
		I_PELVIS5.SetActive(false); 

		Q_LEGS1.SetActive(false); 
		Q_LEGS2.SetActive(false); 
		Q_LEGS3.SetActive(false); 
		Q_LEGS4.SetActive(false); 
		Q_LEGS5.SetActive(false); 

		I_LEGS1.SetActive(false); 
		I_LEGS2.SetActive(false); 
		I_LEGS3.SetActive(false); 
		I_LEGS4.SetActive(false); 
		I_LEGS5.SetActive(false); 

		Q_HANDS1.SetActive(false); 
		Q_HANDS2.SetActive(false); 
		Q_HANDS3.SetActive(false); 
		Q_HANDS4.SetActive(false); 
		Q_HANDS5.SetActive(false); 

		I_HANDS1.SetActive(false); 
		I_HANDS2.SetActive(false); 
		I_HANDS3.SetActive(false); 
		I_HANDS4.SetActive(false); 
		I_HANDS5.SetActive(false); 

		Q_GENERAL_2_3.SetActive(false);
		Q_GENERAL_3_3.SetActive(false);
		Q_HEAD_2_3.SetActive(false);
		Q_HEAD_3_3.SetActive(false);
		Q_NECK_2_3.SetActive(false);
		Q_NECK_3_3.SetActive(false);	
		Q_CHEST_2_3.SetActive(false);
		Q_CHEST_3_3.SetActive(false);
		Q_ABDOMEN_2_3.SetActive(false);
		Q_ABDOMEN_3_3.SetActive(false);
		Q_PELVIS_2_3.SetActive(false);
		Q_PELVIS_3_3.SetActive(false);	
		Q_LEGS_2_3.SetActive(false);
		Q_LEGS_3_3.SetActive(false);
		Q_HANDS_2_3.SetActive(false);
		Q_HANDS_3_3.SetActive(false);

	}

	//=============================
	//    C O N D I T I O N S         
	//=============================
	/******************************
	    QUIZ SHOULDERS BUTOONS  
	******************************/
	public void  B_COND1()
	{
		//C_COND1.SetActive(true);
		C_COND2.SetActive(false);
		C_COND3.SetActive(false);
		C_COND4.SetActive(false);
		C_COND5.SetActive(false);
	}

	public void  B_COND2()
	{
		C_COND1.SetActive(false);
		//C_COND2.SetActive(true);
		C_COND3.SetActive(false);
		C_COND4.SetActive(false);
		C_COND5.SetActive(false);
	}

	public void  B_COND3()
	{
		C_COND1.SetActive(false);
		C_COND2.SetActive(false);
		//C_COND3.SetActive(true);
		C_COND4.SetActive(false);
		C_COND5.SetActive(false);
	}

	public void  B_COND4()
	{
		C_COND1.SetActive(false);
		C_COND2.SetActive(false);
		C_COND3.SetActive(false);
		//C_COND4.SetActive(true);
		C_COND5.SetActive(false);
	}

	public void  B_COND5()
	{
		C_COND1.SetActive(false);
		C_COND2.SetActive(false);
		C_COND3.SetActive(false);
		C_COND4.SetActive(false);
		//C_COND5.SetActive(true);
	}


	//=============================
	//          H E A D          
	//=============================
	/******************************
          QUIZ HEAD BUTTONS  
	******************************/
	public void  BQ_HEAD1()
	{
		//Q_HEAD1.SetActive(false);
		Q_HEAD2.SetActive(false);
		Q_HEAD3.SetActive(false);
		Q_HEAD4.SetActive(false);
		Q_HEAD5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_HEAD2()
	{
		Q_HEAD1.SetActive(false);
		//Q_HEAD2.SetActive(false);
		Q_HEAD3.SetActive(false);
		Q_HEAD4.SetActive(false);
		Q_HEAD5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_HEAD3()
	{
		Q_HEAD1.SetActive(false);
		Q_HEAD2.SetActive(false);
		//Q_HEAD3.SetActive(false);
		Q_HEAD4.SetActive(false);
		Q_HEAD5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_HEAD4()
	{
		Q_HEAD1.SetActive(false);
		Q_HEAD2.SetActive(false);
		Q_HEAD3.SetActive(false);
		//Q_HEAD4.SetActive(false);
		Q_HEAD5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_HEAD5()
	{
		Q_HEAD1.SetActive(false);
		Q_HEAD2.SetActive(false);
		Q_HEAD3.SetActive(false);
		Q_HEAD4.SetActive(false);
		//Q_HEAD5.SetActive(false);
		INFO_CLOSE_ALL();
	}

	/******************************
	      INFO HEAD BUTTONS 
	******************************/
	public void  BI_HEAD1()
	{
		//I_HEAD1.SetActive(false);
		I_HEAD2.SetActive(false);
		I_HEAD3.SetActive(false);
		I_HEAD4.SetActive(false);
		I_HEAD5.SetActive(false);
	}
	public void  BI_HEAD2()
	{
		I_HEAD1.SetActive(false);
		//I_HEAD2.SetActive(false);
		I_HEAD3.SetActive(false);
		I_HEAD4.SetActive(false);
		I_HEAD5.SetActive(false);
	}
	public void  BI_HEAD3()
	{
		I_HEAD1.SetActive(false);
		I_HEAD2.SetActive(false);
		//I_HEAD3.SetActive(false);
		I_HEAD4.SetActive(false);
		I_HEAD5.SetActive(false);
	}
	public void  BI_HEAD4()
	{
		I_HEAD1.SetActive(false);
		I_HEAD2.SetActive(false);
		I_HEAD3.SetActive(false);
		//I_HEAD4.SetActive(false);
		I_HEAD5.SetActive(false);
	}
	public void  BI_HEAD5()
	{
		I_HEAD1.SetActive(false);
		I_HEAD2.SetActive(false);
		I_HEAD3.SetActive(false);
		I_HEAD4.SetActive(false);
		//I_HEAD5.SetActive(false);
	}


	//=============================
	//          N E C K          
	//=============================
	/******************************
          QUIZ NECK BUTTONS  
	******************************/
	public void  BQ_NECK1()
	{
		//Q_NECK1.SetActive(false);
		Q_NECK2.SetActive(false);
		Q_NECK3.SetActive(false);
		Q_NECK4.SetActive(false);
		Q_NECK5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_NECK2()
	{
		Q_NECK1.SetActive(false);
		//Q_NECK2.SetActive(false);
		Q_NECK3.SetActive(false);
		Q_NECK4.SetActive(false);
		Q_NECK5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_NECK3()
	{
		Q_NECK1.SetActive(false);
		Q_NECK2.SetActive(false);
		//Q_NECK3.SetActive(false);
		Q_NECK4.SetActive(false);
		Q_NECK5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_NECK4()
	{
		Q_NECK1.SetActive(false);
		Q_NECK2.SetActive(false);
		Q_NECK3.SetActive(false);
		//Q_NECK4.SetActive(false);
		Q_NECK5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_NECK5()
	{
		Q_NECK1.SetActive(false);
		Q_NECK2.SetActive(false);
		Q_NECK3.SetActive(false);
		Q_NECK4.SetActive(false);
		//Q_NECK5.SetActive(false);
		INFO_CLOSE_ALL();
	}

	/******************************
          INFO NECK BUTTONS  
	******************************/
	public void  BI_NECK1()
	{
		//I_NECK1.SetActive(false);
		I_NECK2.SetActive(false);
		I_NECK3.SetActive(false);
		I_NECK4.SetActive(false);
		I_NECK5.SetActive(false);
	}
	public void  BI_NECK2()
	{
		I_NECK1.SetActive(false);
		//I_NECK2.SetActive(false);
		I_NECK3.SetActive(false);
		I_NECK4.SetActive(false);
		I_NECK5.SetActive(false);
	}
	public void  BI_NECK3()
	{
		I_NECK1.SetActive(false);
		I_NECK2.SetActive(false);
		//I_NECK3.SetActive(false);
		I_NECK4.SetActive(false);
		I_NECK5.SetActive(false);
	}
	public void  BI_NECK4()
	{
		I_NECK1.SetActive(false);
		I_NECK2.SetActive(false);
		I_NECK3.SetActive(false);
		//I_NECK4.SetActive(false);
		I_NECK5.SetActive(false);
	}
	public void  BI_NECK5()
	{
		I_NECK1.SetActive(false);
		I_NECK2.SetActive(false);
		I_NECK3.SetActive(false);
		I_NECK4.SetActive(false);
		//I_NECK5.SetActive(false);
	}

	//=============================
	//         C H E S T          
	//=============================
	/******************************
        QUIZ CHEST BUTTONS  
	******************************/
	public void  BQ_CHEST1()
	{
		//Q_CHEST1.SetActive(false);
		Q_CHEST2.SetActive(false);
		Q_CHEST3.SetActive(false);
		Q_CHEST4.SetActive(false);
		Q_CHEST5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_CHEST2()
	{
		Q_CHEST1.SetActive(false);
		//Q_CHEST2.SetActive(false);
		Q_CHEST3.SetActive(false);
		Q_CHEST4.SetActive(false);
		Q_CHEST5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_CHEST3()
	{
		Q_CHEST1.SetActive(false);
		Q_CHEST2.SetActive(false);
		//Q_CHEST3.SetActive(false);
		Q_CHEST4.SetActive(false);
		Q_CHEST5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_CHEST4()
	{
		Q_CHEST1.SetActive(false);
		Q_CHEST2.SetActive(false);
		Q_CHEST3.SetActive(false);
		//Q_CHEST4.SetActive(false);
		Q_CHEST5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_CHEST5()
	{
		Q_CHEST1.SetActive(false);
		Q_CHEST2.SetActive(false);
		Q_CHEST3.SetActive(false);
		Q_CHEST4.SetActive(false);
		//Q_CHEST5.SetActive(false);
		INFO_CLOSE_ALL();
	}

	/******************************
          INFO CHEST BUTTONS  
	******************************/
	public void  BI_CHEST1()
	{
		//I_CHEST1.SetActive(false);
		I_CHEST2.SetActive(false);
		I_CHEST3.SetActive(false);
		I_CHEST4.SetActive(false);
		I_CHEST5.SetActive(false);
	}
	public void  BI_CHEST2()
	{
		I_CHEST1.SetActive(false);
		//I_CHEST2.SetActive(false);
		I_CHEST3.SetActive(false);
		I_CHEST4.SetActive(false);
		I_CHEST5.SetActive(false);
	}
	public void  BI_CHEST3()
	{
		I_CHEST1.SetActive(false);
		I_CHEST2.SetActive(false);
		//I_CHEST3.SetActive(false);
		I_CHEST4.SetActive(false);
		I_CHEST5.SetActive(false);
	}
	public void  BI_CHEST4()
	{
		I_CHEST1.SetActive(false);
		I_CHEST2.SetActive(false);
		I_CHEST3.SetActive(false);
		//I_CHEST4.SetActive(false);
		I_CHEST5.SetActive(false);
	}
	public void  BI_CHEST5()
	{
		I_CHEST1.SetActive(false);
		I_CHEST2.SetActive(false);
		I_CHEST3.SetActive(false);
		I_CHEST4.SetActive(false);
		//I_CHEST5.SetActive(false);
	}

	//=============================
	//       A D B O M E N           
	//=============================
	/******************************
         QUIZ ABDOMEN BUTTONS  
	******************************/
	public void  BQ_ABDOMEN1()
	{
		//Q_ABDOMEN1.SetActive(false);
		Q_ABDOMEN2.SetActive(false);
		Q_ABDOMEN3.SetActive(false);
		Q_ABDOMEN4.SetActive(false);
		Q_ABDOMEN5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_ABDOMEN2()
	{
		Q_ABDOMEN1.SetActive(false);
		//Q_ABDOMEN2.SetActive(false);
		Q_ABDOMEN3.SetActive(false);
		Q_ABDOMEN4.SetActive(false);
		Q_ABDOMEN5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_ABDOMEN3()
	{
		Q_ABDOMEN1.SetActive(false);
		Q_ABDOMEN2.SetActive(false);
		//Q_ABDOMEN3.SetActive(false);
		Q_ABDOMEN4.SetActive(false);
		Q_ABDOMEN5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_ABDOMEN4()
	{
		Q_ABDOMEN1.SetActive(false);
		Q_ABDOMEN2.SetActive(false);
		Q_ABDOMEN3.SetActive(false);
		//Q_ABDOMEN4.SetActive(false);
		Q_ABDOMEN5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_ABDOMEN5()
	{
		Q_ABDOMEN1.SetActive(false);
		Q_ABDOMEN2.SetActive(false);
		Q_ABDOMEN3.SetActive(false);
		Q_ABDOMEN4.SetActive(false);
		//Q_ABDOMEN5.SetActive(false);
		INFO_CLOSE_ALL();
	}

	/******************************
         INFO ABDOMEN BUTTONS  
	******************************/
	public void  BI_ABDOMEN1()
	{
		//I_ABDOMEN1.SetActive(false);
		I_ABDOMEN2.SetActive(false);
		I_ABDOMEN3.SetActive(false);
		I_ABDOMEN4.SetActive(false);
		I_ABDOMEN5.SetActive(false);
	}
	public void  BI_ABDOMEN2()
	{
		I_ABDOMEN1.SetActive(false);
		//I_ABDOMEN2.SetActive(false);
		I_ABDOMEN3.SetActive(false);
		I_ABDOMEN4.SetActive(false);
		I_ABDOMEN5.SetActive(false);
	}
	public void  BI_ABDOMEN3()
	{
		I_ABDOMEN1.SetActive(false);
		I_ABDOMEN2.SetActive(false);
		//I_ABDOMEN3.SetActive(false);
		I_ABDOMEN4.SetActive(false);
		I_ABDOMEN5.SetActive(false);
	}
	public void  BI_ABDOMEN4()
	{
		I_ABDOMEN1.SetActive(false);
		I_ABDOMEN2.SetActive(false);
		I_ABDOMEN3.SetActive(false);
		//I_ABDOMEN4.SetActive(false);
		I_ABDOMEN5.SetActive(false);
	}
	public void  BI_ABDOMEN5()
	{
		I_ABDOMEN1.SetActive(false);
		I_ABDOMEN2.SetActive(false);
		I_ABDOMEN3.SetActive(false);
		I_ABDOMEN4.SetActive(false);
		//I_ABDOMEN5.SetActive(false);
	}

	//=============================
	//       P E L V I S           
	//=============================
	/******************************
        QUIZ PELVIS BUTTONS  
	******************************/
	public void  BQ_PELVIS1()
	{
		//Q_PELVIS1.SetActive(false);
		Q_PELVIS2.SetActive(false);
		Q_PELVIS3.SetActive(false);
		Q_PELVIS4.SetActive(false);
		Q_PELVIS5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_PELVIS2()
	{
		Q_PELVIS1.SetActive(false);
		//Q_PELVIS2.SetActive(false);
		Q_PELVIS3.SetActive(false);
		Q_PELVIS4.SetActive(false);
		Q_PELVIS5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_PELVIS3()
	{
		Q_PELVIS1.SetActive(false);
		Q_PELVIS2.SetActive(false);
		//Q_PELVIS3.SetActive(false);
		Q_PELVIS4.SetActive(false);
		Q_PELVIS5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_PELVIS4()
	{
		Q_PELVIS1.SetActive(false);
		Q_PELVIS2.SetActive(false);
		Q_PELVIS3.SetActive(false);
		//Q_PELVIS4.SetActive(false);
		Q_PELVIS5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_PELVIS5()
	{
		Q_PELVIS1.SetActive(false);
		Q_PELVIS2.SetActive(false);
		Q_PELVIS3.SetActive(false);
		Q_PELVIS4.SetActive(false);
		//Q_PELVIS5.SetActive(false);
		INFO_CLOSE_ALL();
	}

	/******************************
         INFO PELVIS BUTTONS  
	******************************/
	public void  BI_PELVIS1()
	{
		//I_PELVIS1.SetActive(false);
		I_PELVIS2.SetActive(false);
		I_PELVIS3.SetActive(false);
		I_PELVIS4.SetActive(false);
		I_PELVIS5.SetActive(false);
	}
	public void  BI_PELVIS2()
	{
		I_PELVIS1.SetActive(false);
		//I_PELVIS2.SetActive(false);
		I_PELVIS3.SetActive(false);
		I_PELVIS4.SetActive(false);
		I_PELVIS5.SetActive(false);
	}
	public void  BI_PELVIS3()
	{
		I_PELVIS1.SetActive(false);
		I_PELVIS2.SetActive(false);
		//I_PELVIS3.SetActive(false);
		I_PELVIS4.SetActive(false);
		I_PELVIS5.SetActive(false);
	}
	public void  BI_PELVIS4()
	{
		I_PELVIS1.SetActive(false);
		I_PELVIS2.SetActive(false);
		I_PELVIS3.SetActive(false);
		//I_PELVIS4.SetActive(false);
		I_PELVIS5.SetActive(false);
	}
	public void  BI_PELVIS5()
	{
		I_PELVIS1.SetActive(false);
		I_PELVIS2.SetActive(false);
		I_PELVIS3.SetActive(false);
		I_PELVIS4.SetActive(false);
		//I_PELVIS5.SetActive(false);
	}

	//=============================
	//         L E G S           
	//=============================
	/******************************
        QUIZ LEGS BUTTONS  
	******************************/
	public void  BQ_LEGS1()
	{
		//Q_LEGS1.SetActive(false);
		Q_LEGS2.SetActive(false);
		Q_LEGS3.SetActive(false);
		Q_LEGS4.SetActive(false);
		Q_LEGS5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_LEGS2()
	{
		Q_LEGS1.SetActive(false);
		//Q_LEGS2.SetActive(false);
		Q_LEGS3.SetActive(false);
		Q_LEGS4.SetActive(false);
		Q_LEGS5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_LEGS3()
	{
		Q_LEGS1.SetActive(false);
		Q_LEGS2.SetActive(false);
		//Q_LEGS3.SetActive(false);
		Q_LEGS4.SetActive(false);
		Q_LEGS5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_LEGS4()
	{
		Q_LEGS1.SetActive(false);
		Q_LEGS2.SetActive(false);
		Q_LEGS3.SetActive(false);
		//Q_LEGS4.SetActive(false);
		Q_LEGS5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_LEGS5()
	{
		Q_LEGS1.SetActive(false);
		Q_LEGS2.SetActive(false);
		Q_LEGS3.SetActive(false);
		Q_LEGS4.SetActive(false);
		//Q_LEGS5.SetActive(false);
		INFO_CLOSE_ALL();
	}

	/******************************
          INFO LEGS BUTTONS  
	******************************/
	public void  BI_LEGS1()
	{
		//I_LEGS1.SetActive(false);
		I_LEGS2.SetActive(false);
		I_LEGS3.SetActive(false);
		I_LEGS4.SetActive(false);
		I_LEGS5.SetActive(false);
	}
	public void  BI_LEGS2()
	{
		I_LEGS1.SetActive(false);
		//I_LEGS2.SetActive(false);
		I_LEGS3.SetActive(false);
		I_LEGS4.SetActive(false);
		I_LEGS5.SetActive(false);
	}
	public void  BI_LEGS3()
	{
		I_LEGS1.SetActive(false);
		I_LEGS2.SetActive(false);
		//I_LEGS3.SetActive(false);
		I_LEGS4.SetActive(false);
		I_LEGS5.SetActive(false);
	}
	public void  BI_LEGS4()
	{
		I_LEGS1.SetActive(false);
		I_LEGS2.SetActive(false);
		I_LEGS3.SetActive(false);
		//I_LEGS4.SetActive(false);
		I_LEGS5.SetActive(false);
	}
	public void  BI_LEGS5()
	{
		I_LEGS1.SetActive(false);
		I_LEGS2.SetActive(false);
		I_LEGS3.SetActive(false);
		I_LEGS4.SetActive(false);
		//I_LEGS5.SetActive(false);
	}

	//=============================
	//         H A N D S           
	//=============================
	/******************************
          QUIZ HANDS BUTTONS  
	******************************/
	public void  BQ_HANDS1()
	{
		//Q_HANDS1.SetActive(false);
		Q_HANDS2.SetActive(false);
		Q_HANDS3.SetActive(false);
		Q_HANDS4.SetActive(false);
		Q_HANDS5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_HANDS2()
	{
		Q_HANDS1.SetActive(false);
		//Q_HANDS2.SetActive(false);
		Q_HANDS3.SetActive(false);
		Q_HANDS4.SetActive(false);
		Q_HANDS5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_HANDS3()
	{
		Q_HANDS1.SetActive(false);
		Q_HANDS2.SetActive(false);
		//Q_HANDS3.SetActive(false);
		Q_HANDS4.SetActive(false);
		Q_HANDS5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_HANDS4()
	{
		Q_HANDS1.SetActive(false);
		Q_HANDS2.SetActive(false);
		Q_HANDS3.SetActive(false);
		//Q_HANDS4.SetActive(false);
		Q_HANDS5.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_HANDS5()
	{
		Q_HANDS1.SetActive(false);
		Q_HANDS2.SetActive(false);
		Q_HANDS3.SetActive(false);
		Q_HANDS4.SetActive(false);
		//Q_HANDS5.SetActive(false);
		INFO_CLOSE_ALL();
	}

	/******************************
          INFO HANDS BUTTONS  
	******************************/
	public void  BI_HANDS1()
	{
		//I_HANDS1.SetActive(false);
		I_HANDS2.SetActive(false);
		I_HANDS3.SetActive(false);
		I_HANDS4.SetActive(false);
		I_HANDS5.SetActive(false);
	}
	public void  BI_HANDS2()
	{
		I_HANDS1.SetActive(false);
		//I_HANDS2.SetActive(false);
		I_HANDS3.SetActive(false);
		I_HANDS4.SetActive(false);
		I_HANDS5.SetActive(false);
	}
	public void  BI_HANDS3()
	{
		I_HANDS1.SetActive(false);
		I_HANDS2.SetActive(false);
		//I_HANDS3.SetActive(false);
		I_HANDS4.SetActive(false);
		I_HANDS5.SetActive(false);
	}
	public void  BI_HANDS4()
	{
		I_HANDS1.SetActive(false);
		I_HANDS2.SetActive(false);
		I_HANDS3.SetActive(false);
		//I_HANDS4.SetActive(false);
		I_HANDS5.SetActive(false);
	}
	public void  BI_HANDS5()
	{
		I_HANDS1.SetActive(false);
		I_HANDS2.SetActive(false);
		I_HANDS3.SetActive(false);
		I_HANDS4.SetActive(false);
		//I_HANDS5.SetActive(false);
	}


	//=============================
	//      S H O U L D E R S          
	//=============================
	/******************************
	    QUIZ SHOULDERS BUTTONS  
	******************************/
	public void  BQ_SHOULDERS1()
	{
		//Q_SHOULDERS1.SetActive(true);
		Q_SHOULDERS2.SetActive(false);
		Q_SHOULDERS3.SetActive(false);
		Q_SHOULDERS4.SetActive(false);
		Q_SHOULDERS5.SetActive(false);
		Q_SHOULDERS6.SetActive(false);
		Q_SHOULDERS7.SetActive(false);
		INFO_CLOSE_ALL();

	}
	
	public void  BQ_SHOULDERS2()
	{
		Q_SHOULDERS1.SetActive(false);
		//Q_SHOULDERS2.SetActive(true);
		Q_SHOULDERS3.SetActive(false);
		Q_SHOULDERS4.SetActive(false);
		Q_SHOULDERS5.SetActive(false);
		Q_SHOULDERS6.SetActive(false);
		Q_SHOULDERS7.SetActive(false);
		INFO_CLOSE_ALL();
	}
	
	public void  BQ_SHOULDERS3()
	{
		Q_SHOULDERS1.SetActive(false);
		Q_SHOULDERS2.SetActive(false);
		//Q_SHOULDERS3.SetActive(true);
		Q_SHOULDERS4.SetActive(false);
		Q_SHOULDERS5.SetActive(false);
		Q_SHOULDERS6.SetActive(false);
		Q_SHOULDERS7.SetActive(false);
		INFO_CLOSE_ALL();
	}
	
	public void  BQ_SHOULDERS4()
	{
		Q_SHOULDERS1.SetActive(false);
		Q_SHOULDERS2.SetActive(false);
		Q_SHOULDERS3.SetActive(false);
		//Q_SHOULDERS4.SetActive(true);
		Q_SHOULDERS5.SetActive(false);
		Q_SHOULDERS6.SetActive(false);
		Q_SHOULDERS7.SetActive(false);
		INFO_CLOSE_ALL();
	}
	
	public void  BQ_SHOULDERS5()
	{
		Q_SHOULDERS1.SetActive(false);
		Q_SHOULDERS2.SetActive(false);
		Q_SHOULDERS3.SetActive(false);
		Q_SHOULDERS4.SetActive(false);
		//Q_SHOULDERS5.SetActive(true);
		Q_SHOULDERS6.SetActive(false);
		Q_SHOULDERS7.SetActive(false);
		INFO_CLOSE_ALL();
	}
	
	public void  BQ_SHOULDERS6()
	{
		Q_SHOULDERS1.SetActive(false);
		Q_SHOULDERS2.SetActive(false);
		Q_SHOULDERS3.SetActive(false);
		Q_SHOULDERS4.SetActive(false);
		Q_SHOULDERS5.SetActive(false);
		//Q_SHOULDERS6.SetActive(true);
		Q_SHOULDERS7.SetActive(false);
		INFO_CLOSE_ALL();
	}
	
	public void  BQ_SHOULDERS7()
	{
		Q_SHOULDERS1.SetActive(false);
		Q_SHOULDERS2.SetActive(false);
		Q_SHOULDERS3.SetActive(false);
		Q_SHOULDERS4.SetActive(false);
		Q_SHOULDERS5.SetActive(false);
		Q_SHOULDERS6.SetActive(false);
		//Q_SHOULDERS7.SetActive(true);
		INFO_CLOSE_ALL();
	}

	/******************************
	    INFO SHOULDERS BUTTONS 
	******************************/
	public void  BI_SHOULDERS1()
	{
		//I_SHOULDERS1.SetActive(true);
		I_SHOULDERS2.SetActive(false);
		I_SHOULDERS3.SetActive(false);
		I_SHOULDERS4.SetActive(false);
		I_SHOULDERS5.SetActive(false);
		I_SHOULDERS6.SetActive(false);
		I_SHOULDERS7.SetActive(false);
	}
		
	public void  BI_SHOULDERS2()
	{
		I_SHOULDERS1.SetActive(false);
		//I_SHOULDERS2.SetActive(true);
		I_SHOULDERS3.SetActive(false);
		I_SHOULDERS4.SetActive(false);
		I_SHOULDERS5.SetActive(false);
		I_SHOULDERS6.SetActive(false);
		I_SHOULDERS7.SetActive(false);
	}

	public void  BI_SHOULDERS3()
	{
		I_SHOULDERS1.SetActive(false);
		I_SHOULDERS2.SetActive(false);
		//I_SHOULDERS3.SetActive(true);
		I_SHOULDERS4.SetActive(false);
		I_SHOULDERS5.SetActive(false);
		I_SHOULDERS6.SetActive(false);
		I_SHOULDERS7.SetActive(false);
	}

	public void  BI_SHOULDERS4()
	{
		I_SHOULDERS1.SetActive(false);
		I_SHOULDERS2.SetActive(false);
		I_SHOULDERS3.SetActive(false);
		//I_SHOULDERS4.SetActive(true);
		I_SHOULDERS5.SetActive(false);
		I_SHOULDERS6.SetActive(false);
		I_SHOULDERS7.SetActive(false);
	}

	public void  BI_SHOULDERS5()
	{
		I_SHOULDERS1.SetActive(false);
		I_SHOULDERS2.SetActive(false);
		I_SHOULDERS3.SetActive(false);
		I_SHOULDERS4.SetActive(false);
		//I_SHOULDERS5.SetActive(true);
		I_SHOULDERS6.SetActive(false);
		I_SHOULDERS7.SetActive(false);
	}

	public void  BI_SHOULDERS6()
	{
		I_SHOULDERS1.SetActive(false);
		I_SHOULDERS2.SetActive(false);
		I_SHOULDERS3.SetActive(false);
		I_SHOULDERS4.SetActive(false);
		I_SHOULDERS5.SetActive(false);
		//I_SHOULDERS6.SetActive(true);
		I_SHOULDERS7.SetActive(false);
	}

	public void  BI_SHOULDERS7()
	{
		I_SHOULDERS1.SetActive(false);
		I_SHOULDERS2.SetActive(false);
		I_SHOULDERS3.SetActive(false);
		I_SHOULDERS4.SetActive(false);
		I_SHOULDERS5.SetActive(false);
		I_SHOULDERS6.SetActive(false);
		//I_SHOULDERS7.SetActive(true);
	}


	//==============================
	//        G E N E R A L
	//==============================
	/******************************
	    QUIZ GENREAL BUTTONS  
	******************************/
	public void  BQ_GENERAL1()
	{
		//Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL2()
	{
		Q_GENERAL1.SetActive(false);
		//Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL3()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		//Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL4()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		//Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL5()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		//Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL6()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		//Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL7()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		//Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL8()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		//Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL9()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		//Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL10()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		//Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL11()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		//Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL12()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		//Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL13()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		//Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL14()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		//Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL15()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		//Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}

	public void  BQ_GENERAL16()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		//Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL17()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		//Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL18()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		//Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL19()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		//Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL20()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		//Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL21()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		//Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL22()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		//Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL23()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		//Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL24()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		//Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL25()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		//Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL26()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		//Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL27()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		//Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL28()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		//Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL29()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		//Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL30()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		//Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL31()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		//Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL32()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		//Q_GENERAL32.SetActive(false);
		Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}
	public void  BQ_GENERAL33()
	{
		Q_GENERAL1.SetActive(false);
		Q_GENERAL2.SetActive(false);
		Q_GENERAL3.SetActive(false);
		Q_GENERAL4.SetActive(false);
		Q_GENERAL5.SetActive(false);
		Q_GENERAL6.SetActive(false);
		Q_GENERAL7.SetActive(false);
		Q_GENERAL8.SetActive(false);
		Q_GENERAL9.SetActive(false);
		Q_GENERAL10.SetActive(false);
		Q_GENERAL11.SetActive(false);
		Q_GENERAL12.SetActive(false);
		Q_GENERAL13.SetActive(false);
		Q_GENERAL14.SetActive(false);
		Q_GENERAL15.SetActive(false);
		Q_GENERAL16.SetActive(false);
		Q_GENERAL17.SetActive(false);
		Q_GENERAL18.SetActive(false);
		Q_GENERAL19.SetActive(false);
		Q_GENERAL20.SetActive(false);
		Q_GENERAL21.SetActive(false);
		Q_GENERAL22.SetActive(false);
		Q_GENERAL23.SetActive(false);
		Q_GENERAL24.SetActive(false);
		Q_GENERAL25.SetActive(false);
		Q_GENERAL26.SetActive(false);
		Q_GENERAL27.SetActive(false);
		Q_GENERAL28.SetActive(false);
		Q_GENERAL29.SetActive(false);
		Q_GENERAL30.SetActive(false);
		Q_GENERAL31.SetActive(false);
		Q_GENERAL32.SetActive(false);
		//Q_GENERAL33.SetActive(false);
		INFO_CLOSE_ALL();
	}


	/******************************
	    INFO GENREAL BUTTONS  
	******************************/
	public void  BI_GENERAL1()
	{
		//I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL2()
	{
		I_GENERAL1.SetActive(false);
		//I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL3()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		//I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL4()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		//I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL5()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		//I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL6()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		//I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL7()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		//I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL8()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		//I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL9()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		//I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL10()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		//I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL11()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		//I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL12()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		//I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL13()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		//I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL14()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		//I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL15()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		//I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}

	public void  BI_GENERAL16()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		//I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL17()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		//I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL18()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		//I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL19()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		//I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL20()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		//I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL21()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		//I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL22()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		//I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL23()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		//I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL24()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		//I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL25()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		//I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL26()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		//I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL27()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		//I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL28()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		//I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL29()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		//I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL30()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		//I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL31()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		//I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL32()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		//I_GENERAL32.SetActive(false);
		I_GENERAL33.SetActive(false);
	}
	public void  BI_GENERAL33()
	{
		I_GENERAL1.SetActive(false);
		I_GENERAL2.SetActive(false);
		I_GENERAL3.SetActive(false);
		I_GENERAL4.SetActive(false);
		I_GENERAL5.SetActive(false);
		I_GENERAL6.SetActive(false);
		I_GENERAL7.SetActive(false);
		I_GENERAL8.SetActive(false);
		I_GENERAL9.SetActive(false);
		I_GENERAL10.SetActive(false);
		I_GENERAL11.SetActive(false);
		I_GENERAL12.SetActive(false);
		I_GENERAL13.SetActive(false);
		I_GENERAL14.SetActive(false);
		I_GENERAL15.SetActive(false);
		I_GENERAL16.SetActive(false);
		I_GENERAL17.SetActive(false);
		I_GENERAL18.SetActive(false);
		I_GENERAL19.SetActive(false);
		I_GENERAL20.SetActive(false);
		I_GENERAL21.SetActive(false);
		I_GENERAL22.SetActive(false);
		I_GENERAL23.SetActive(false);
		I_GENERAL24.SetActive(false);
		I_GENERAL25.SetActive(false);
		I_GENERAL26.SetActive(false);
		I_GENERAL27.SetActive(false);
		I_GENERAL28.SetActive(false);
		I_GENERAL29.SetActive(false);
		I_GENERAL30.SetActive(false);
		I_GENERAL31.SetActive(false);
		I_GENERAL32.SetActive(false);
		//I_GENERAL33.SetActive(false);
	}


}
