﻿/**********************************************************
  CameraControl.cs 
	Symptom Cheker (alpha)

  Writing by Sergey Gasanov, aug,2015 
  version: 0.2
**********************************************************/

using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class CameraControl : MonoBehaviour 
{

	public Camera cam; 				
	public Text NameBody; 

	// Male or Female
	public Toggle ToggleMale;				
	public Toggle ToggleFemale;				

	// DAZ MALE
	public GameObject head_ml; 
	public GameObject neck_ml; 
	public GameObject adomen_ml; 
	public GameObject pelvis_ml; 
	public GameObject chest_ml; 
	public GameObject lForeArm_ml; 
	public GameObject lHand_ml; 
	public GameObject rForeArm_ml; 
	public GameObject rHand_ml; 
	public GameObject lThigh_ml; 
	public GameObject rThigh_ml; 
	public GameObject lShin_ml; 
	public GameObject rShin_ml; 
	public GameObject lFoot_ml; 
	public GameObject rFoot_ml; 
	public GameObject lCollar_ml; 
	public GameObject rCollar_ml; 
	public GameObject lShldr_ml; 
	public GameObject rShldr_ml; 

	// DAZ FEMALE
	public GameObject head_fm; 
	public GameObject neck_fm; 
	public GameObject adomen_fm; 
	public GameObject pelvis_fm; 
	public GameObject chest_fm; 
	public GameObject lForeArm_fm; 
	public GameObject lHand_fm; 
	public GameObject rForeArm_fm; 
	public GameObject rHand_fm; 
	public GameObject lThigh_fm; 
	public GameObject rThigh_fm; 
	public GameObject lShin_fm; 
	public GameObject rShin_fm; 
	public GameObject lFoot_fm; 
	public GameObject rFoot_fm; 
	public GameObject lCollar_fm; 
	public GameObject rCollar_fm; 
	public GameObject lShldr_fm; 
	public GameObject rShldr_fm; 

	void Start ()
	{
		CamReset ();
	}


	public void CamReset ()
	{
		cam.GetComponent<MOrbit_SG>().nx = 180.0f;
		cam.GetComponent<MOrbit_SG>().ny = 5.0f;
		cam.GetComponent<MOrbit_SG>().nz = 2.62f;

		if (ToggleMale.isOn)
			cam.GetComponent<MOrbit_SG>().target = pelvis_ml;
		else
			cam.GetComponent<MOrbit_SG>().target = pelvis_fm;

	}

	public void CamFocus () 
	{
    	cam.GetComponent<MOrbit_SG>().nx = 180.0f;
		cam.GetComponent<MOrbit_SG>().ny = 5.0f;
		cam.GetComponent<MOrbit_SG>().nz = 1.0f;

		switch (NameBody.text)
		{
			case "HEAD":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = head_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = head_fm;
			break;
			
			case "NECK":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = neck_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = neck_fm;
			break;
			
			case "ABDOMEN":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = adomen_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = adomen_fm;
			break;
			
			case "CHEST":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = chest_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = chest_fm;
			break;
			
			case "PELVIS":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = pelvis_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = pelvis_fm;
			break;
			
			case "RIGHT FOREARM":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = rForeArm_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = rForeArm_fm;
			break;

			case "LEFT FOREARM":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = lForeArm_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = lForeArm_fm;
			break;

			case "LEFT SHOULDER":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = lShldr_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = lShldr_fm;
			break;

			case "RIGHT SHOULDER":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = rShldr_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = rShldr_fm;
			break;
		
			case "RIGHT HAND":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = rHand_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = rHand_fm;
			break;

			case "LEFT HAND":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = lHand_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = lHand_fm;
			break;
			
			case "LEFT SHIN":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = lShin_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = lShin_fm;
			break;

			case "RIGHT SHIN":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = rShin_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = rShin_fm;
			break;

			case "LEFT THIGH":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = lThigh_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = lThigh_fm;
			break;

			case "RIGHT THIGH":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = rThigh_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = rThigh_fm;
			break;

			case "LEFT FOOT":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = lFoot_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = lFoot_fm;
			break;

			case "RIGHT FOOT":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = rFoot_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = rFoot_fm;
			break;
					
			case "RIGHT WRIST":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = rHand_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = rHand_fm;
			break;
		
			case "LEFT WRIST":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = lHand_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = lHand_fm;
			break;

			case "LEFT SHOULDER JOINT":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = lCollar_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = lCollar_fm;
			break;

			case "RIGHT SHOULDER JOINT":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = rCollar_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = rCollar_fm;
			break;

			case "LEFT ELBOW JOINT":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = lForeArm_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = lForeArm_fm;
			break;

			case "RIGHT ELBOW JOINT":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = rForeArm_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = rForeArm_fm;
			break;

			case "LEFT KNEE JOINT":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = lShin_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = lShin_fm;
			break;

			case "RIGHT KNEE JOINT":
			if (ToggleMale.isOn)
				cam.GetComponent<MOrbit_SG>().target = rShin_ml;
			else
				cam.GetComponent<MOrbit_SG>().target = rShin_fm;
			break;
			
			default:
			break;
		}
				 
	}
}
