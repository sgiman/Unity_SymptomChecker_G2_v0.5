﻿
using UnityEngine;

public class SoftBody : MonoBehaviour
{
	// Voxelize up a mesh into cubes, could do tetras I suppose
}