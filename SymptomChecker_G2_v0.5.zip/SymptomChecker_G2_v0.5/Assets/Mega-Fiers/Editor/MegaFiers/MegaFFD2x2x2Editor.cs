﻿using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MegaFFD2x2x2))]
public class MegaFFD2x2x2Editor : MegaFFDEditor
{
	public override string GetHelpString() { return "FFD2x2x2 Modifier by Chris West"; }
}