﻿
using UnityEditor;

[CustomEditor(typeof(MegaSimpleMod))]
public class MegaSimpleModEditor : MegaModifierEditor
{
}
