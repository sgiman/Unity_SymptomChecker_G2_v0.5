﻿
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(MegaFFD4x4x4))]
public class MegaFFD4x4x4Editor : MegaFFDEditor
{
	public override string GetHelpString() { return "FFD4x4x4 Modifier by Chris West"; }
}